The following datasets have been employed for running the experiments described in the two following papers:

a. Elias Bassani, and Marco Viviani. "Feature Analysis for Assessing the Quality of Wikipedia Articles through Supervised Classification." arXiv preprint arXiv:1812.02655 (2018).

b. Elias Bassani, and Marco Viviani. "Automatically Assessing the Quality of Wikipedia Contents". Proceedings of The 34th ACM/SIGAPP Symposium On Applied Computing. Limassol, Cyprus (2019)

Legend:



1 - MH = Military History


2 - FA = Featured Articles


3 - Parallel = articles versions actually classified by WikiProject Military History




Datasets:



1 - MHDataset.csv = Dataset used in the first experiment (paper a. and paper b.), second experiment (paper a.) and fourth experiments (paper b. in this esperiment, some columns were dropped, as described in the paper)


2 - MH_FA_NON-FA_Dataset.csv = Dataset used in the second experiment (paper b.)


3 - MHTwoClassesDataset.csv = Dataset used in the third experiment (paper b.)


4 - MHParallelDataset.csv = Dataset used in the fourth experiment (paper b.)